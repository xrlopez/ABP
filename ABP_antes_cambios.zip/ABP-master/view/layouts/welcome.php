<?php 
 // file: view/layouts/welcome.php
 
 require_once(__DIR__."/../../core/ViewManager.php");
 $view = ViewManager::getInstance();
 
?>
<?php
      include(__DIR__."/default.php");
?>
    